<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="icon" href="favicon/favicon.ico" type="image/x-icon" />
		<link rel="stylesheet" href="css/index.css" type="text/css" />
		<link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Play&display=swap" rel="stylesheet" />
		<title>Progetto d'Esame - Pagina iniziale</title>
	</head>
	<body>
		<header>
			<h1>MATERIALI PININFARINA</h1>
		</header>
		<h2>A cosa serve?</h2>
		<p class="text">
			Benvenuti nel nuovo sito innovativo dedicato alla gestione dei materiali nei laboratori scolastici! Nasce da una
			sfida comune: come rendere più efficiente e trasparente il processo di gestione dei materiali nella nostra scuola?
			La risposta è qui, a portata di clic! Immaginate un luogo virtuale dove i professori possono facilmente
			visualizzare e monitorare tutti i materiali presenti nei laboratori scolastici, con la chiarezza di un inventario
			digitale. Ecco a voi il nostro sito, progettato per semplificare la vita quotidiana degli insegnanti, rendendo la
			gestione dei materiali un'esperienza fluida e intuitiva. Attraverso un'interfaccia grafica intuitiva, i professori
			potranno esplorare l'ampia gamma di materiali disponibili, organizzati in modo ordinato e facilmente accessibile.
			Da sostanze chimiche a strumenti scientifici, tutto sarà a portata di mano. Visualizzate quantità e dettagli su
			qualsiasi tipo di materiale. Il vostro laboratorio diventerà un luogo in cui l'apprendimento è facilitato dalla
			chiarezza e dalla disponibilità di risorse. Ma non è tutto! Il nostro sito offre anche la possibilità di prestito,
			restituzione e persino la rimozione definitiva di materiali. Grazie a un sistema di prenotazioni integrato, i
			professori possono richiedere l'uso di specifici materiali in anticipo, garantendo così una distribuzione equa
			delle risorse e evitando possibili conflitti di prenotazione. La funzione di restituzione è altrettanto semplice.
			Basta un click per segnalare che il materiale è tornato al suo posto, pronto per essere utilizzato da altri
			docenti o studenti. E se un materiale è diventato obsoleto o non più utile, la funzione di eliminazione definitiva
			garantisce una gestione snella e responsabile del magazzino. Unisciti a noi nella rivoluzione della gestione dei
			laboratori scolastici. Il nostro sito è il partner digitale che trasforma la complessità della gestione dei
			materiali in un'esperienza educativa più chiara, efficiente e piacevole. La conoscenza è potere, e con il nostro
			sito, la vostra scuola sarà pronta a raggiungere nuove vette di eccellenza nell'insegnamento e nell'apprendimento.
		</p>
		<?php
		include("code/menu.html");
		?>
		<?php
		include("code/footer.html");
		?>
	</body>
</html>
