<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="icon" href="../favicon/favicon.ico" type="image/x-icon" />
		<link rel="stylesheet" href="../css/index.css" type="text/css" />
		<link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Play&display=swap" rel="stylesheet" />
		<title>Progetto d'Esame - Pagina materiali elettronica</title>
	</head>
	<body>
		<header>
			<h1>MATERIALI PININFARINA</h1>
		</header>
		<?php
		include("../code/menu.html");
		?>
		<h2>A cosa serve?</h1>
		<p class="text">dfhhhhhhhhvhhrty6e 5e uvv6thr</p>
		<?php
		include("../code/footer.html");
		?>
	</body>
</html>